
import java.util.ArrayList;
import java.util.List;

public class TestCalculator {
    public static void main(String[] args) {
        ArrayList<String> ls=toInfix("12+(31-4)*(9+6)-9");
        System.out.println("中缀表达式："+ls);
        ArrayList arrayList=shiftExpression(ls);
        System.out.println("后缀表达式："+arrayList);
        double total=calculate(arrayList);
        System.out.println("值："+total);
    }
    //把表达式进行拆分的静态方法
    public static ArrayList<String> toInfix(String s){
        ArrayList<String> ls=new ArrayList<>();
        int i=0;
        String str;
        char c;
        while (i<s.length()){
            //判断的char为非数字情况
            if ((c=s.charAt(i))<48||(c=s.charAt(i))>57){
                ls.add(""+c);
                i++;

            }
            //判断的char为数字情况
            else {
                str="";
                //考虑多位数
                while (i<s.length()&&(c=s.charAt(i))>=48&&(c=s.charAt(i))<=57){
                    str+=c;//拼接数字
                    i++;
                }
                ls.add(str);
            }
        }
        return ls;
    }
    public static ArrayList<String> shiftExpression(ArrayList<String> ls){
        Stack<String> s1=new Stack<String>(10);//存储运算符号符号
        ArrayList<String> s2=new ArrayList<>();//存储逆波兰表达式
        for (String item:ls) {
            //如果是一个数
            if (item.matches("\\d+")){
                s2.add(item);
            }else if (item.equals("(")){
                s1.push(item);
            }else if (item.equals(")")){//匹配到右括号
                while (!(s1.peek().equals("("))){
                    s2.add(s1.pop());
                }
                s1.pop();//弹出（!
            }
            else{
                if (s1.empty()){
                    s1.push(item);
                }
                else {
                    while ((!s1.empty()) && Operation.getValue(s1.peek()) >= Operation.getValue(item)) {
                        s2.add(s1.pop());
                    }
                    s1.push(item);
                }
            }
        }
        while (!s1.empty()){
            s2.add(s1.pop());
        }
        return s2;
    }
    public static double calculate(ArrayList<String> arrayList){

        ArrayList<Object> arr=new ArrayList<Object>();
        for (int i = 0; i <arrayList.size() ; i++) {
            if ((!arrayList.get(i).equals("+"))&&
                    (!arrayList.get(i).equals("-"))&&
                    (!arrayList.get(i).equals("*"))&&
                    (!arrayList.get(i).equals("/"))){
                double num=Double.parseDouble(arrayList.get(i));
                arr.add(num);
            }else
                arr.add(arrayList.get(i));
        }
        for (int i = 0; i < arr.size(); i++) {
            if (arr.get(i).equals("+")){
                double m=(double)arr.get(i-2)+(double)arr.get(i-1);
                i-=2;
                arr.set(i,m);
                arr.remove(i+1);
                arr.remove(i+1);

            }
            if (arr.get(i).equals("-")){
                double m=(double)arr.get(i-2)-(double)arr.get(i-1);
                i-=2;
                arr.set(i,m);
                arr.remove(i+1);
                arr.remove(i+1);
            }
            if (arr.get(i).equals("*")){
                double m=(double)arr.get(i-2)*(double)arr.get(i-1);
                i-=2;
                arr.set(i,m);
                arr.remove(i+1);
                arr.remove(i+1);
            }
            if (arr.get(i).equals("/")){
                double m=(double)arr.get(i-2)/(double)arr.get(i-1);
                i-=2;
                arr.set(i,m);
                arr.remove(i+1);
                arr.remove(i+1);
            }
        }




        return (double)arr.get(0);
    }
}
class Operation{
    private static int ADD=1;
    private static int SUB=1;
    private static int MUL=2;
    private static int DIV=2;
    public static int getValue(String s){
        switch (s){
            case "+":return ADD;
            case "-":return SUB;
            case "*":return MUL;
            case "/":return DIV;
            case "(":return 0;
            case ")":return 3;
            default:{
                System.out.println("Error");
                return -1;
            }
        }
    }
}