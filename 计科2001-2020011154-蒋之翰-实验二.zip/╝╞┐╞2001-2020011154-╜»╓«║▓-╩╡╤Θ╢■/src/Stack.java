
//数组栈
public class Stack<E> {
    private int top=-1;//栈顶的初始值为-1
    private Object[] arrayStack;//栈
    private int maxSize;//栈最大容量

    //初始化栈
    public Stack(int maxSize) {
        this.maxSize = maxSize;
        arrayStack=new Object[maxSize];
    }
    //查看个数
    public int size(){
        return top+1;
    }
    //判空
    public boolean empty(){
        return top==-1;
    }
    //判满
    public  boolean full(){
        return top==maxSize-1;
    }
    //入栈
    public void push(E ele){
        if (full()){
            System.out.println("栈满，无法入栈！");
        }
        else{
            top++;
            arrayStack[top]=ele;
        }
    }
    //出栈
    public E pop(){
        if (empty()){
            System.out.println("栈空，无法出栈！");
            return null;
        }
        else{
            Object e=arrayStack[top];
            top--;
            return (E)e;

        }
    }
    //查看栈顶元素（未出栈）
    public E peek(){
        if (!empty()) {
            return (E) arrayStack[top];
        }
        return null;
    }
    //遍历栈
    public void all(){
        for(int i=top;i>=0;i--){
            System.out.println(arrayStack[i]);
        }
    }
}
/*测试
class T1{
    public static void main(String[] args) {
        Stack s=new Stack(4);
        System.out.println(s.empty());
        s.push(1);
        s.push(2);
        System.out.println(s.empty());
        System.out.println(s.full());
        s.push(3);
        s.push(4);
        System.out.println(s.full());
        s.all();
    }
}*/
